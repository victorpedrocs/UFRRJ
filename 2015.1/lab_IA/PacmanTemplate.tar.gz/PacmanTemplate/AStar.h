#ifndef _ASTAR_H_
#define _ASTAR_H_

#define WALLCOST 10
#define MAZECOST 1;
struct stNode{
    int x;          //Posio X do n
    int y;          //Posio Y do n
    int G;          //Custo G -> percorrigo
    int H;          //Custo H -> estimado
    int F;          //Custo F = G + H
    stNode *ptrFather;
    stNode *ptrChild;
    
};

void insertSorted(stNode **top, stNode *nNode);
void insert(stNode **top, stNode *nNode);
void removeList(stNode **ptrR);
stNode * inTheList(stNode *top, int x, int y);
void copyNode(stNode * destination, stNode* source);
void debugList(stNode *node);
unsigned long destroyList(stNode **ptrR);
void buildPath(stNode *bottom);
#endif