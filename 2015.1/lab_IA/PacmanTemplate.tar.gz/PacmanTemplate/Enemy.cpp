#include <Enemy.h>
#include <cstdio>
#include <cmath>
#include <iostream>
#include <climits>
#include <ctime>
using namespace std;
Enemy::Enemy()
{

    this->reset();
    glEnable ( GL_TEXTURE_2D );
    assert(LoadTGA(&mTexture, "Ghost.tga") != false);

};


Enemy::Enemy(float x, float y, int i, int id):
Agent(),
mTopClose(NULL),
mTopOpen(NULL),
mPath(true),
mInter(0.0f),
mStopped(true),
mCatch(false),
mID(id)
{

    int  k = i + 65536;
    this->Xi = x;
    this->Yi = y;
    this->reset();
    glEnable ( GL_TEXTURE_2D );
    assert(LoadTGA(&mTexture, "ghost.tga") != false);
    
};

Enemy::~Enemy(void)
{};




void Enemy::back(void)
{
    X = X1;
    Y = Y1;
/*
    mMaxX = X+mSize;;
    mMinX = X-mSize;
    mMaxY = Y+mSize;
    mMinY = Y-mSize;
   */ 
    VX = 0.0f;
    VY = 0.0f;

};

bool Enemy::testCollision(void){
    
    
    if (mAgent->mMaxX < this->mMinX)
        return false;
    
    if (mAgent->mMinX > this->mMaxX)
        return false;
    
    if (mAgent->mMaxY < this->mMinY)
        return false;
    
    if (mAgent->mMinY > this->mMaxY)
        return false;
    
    return true;
        
}

void Enemy::updated(float elapsedTime)
{

}

void Enemy::reset(void){
    Agent::reset();
    mStopped = true;
    
}

void Enemy::render(void){
    //draw current pacman
    
    glPushMatrix();
    glColor4f(1.0f,1.0f,1.0f,1.0f);
    
    
    glTranslatef(X, Y, 0.0f);
    glEnable ( GL_TEXTURE_2D );
    glBindTexture(GL_TEXTURE_2D, mTexture.texID);
   
    
    
    
    glBegin(GL_QUADS);
        glTexCoord2f(0.0f, 0.0f);glVertex2f(0.0f, 0.0f);
        glTexCoord2f(1.0f, 0.0f); glVertex2f(1.0f, 0.0f);
        glTexCoord2f(1.0f, 1.0f);glVertex2f(1.0f, 1.0f);
        glTexCoord2f(0.0f, 1.0f);glVertex2f(0.0f, 1.0f);
  
    glEnd();

    glPopMatrix();
    

}
void Enemy::rAStar(void){

}

void Enemy::cAStar(void){
    
         
}


void  Enemy::setAgent(Agent *agent){
    mAgent = agent;  
    
}

void Enemy::setScene(Scene *scene){
    mScene = scene;
}

int Enemy::fh(int x, int y){
    return   (int) fabs(mAgent->X - (float)x)+fabs(mAgent->Y - (float) y);
}


void Enemy::check(int i, int j){

}

void Enemy::debugCloseList(void){
    

}

void Enemy::print(void){
    cout << "Enemy" << endl;
    cout.flush();
}
